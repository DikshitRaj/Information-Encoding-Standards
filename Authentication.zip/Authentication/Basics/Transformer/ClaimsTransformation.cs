﻿using Microsoft.AspNetCore.Authentication;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace Basics.Transformer
{
    public class ClaimsTransformation : IClaimsTransformation
    {
        public Task<ClaimsPrincipal> TransformAsync(ClaimsPrincipal principal)
        {
            var hasAllowedClaim = principal.Claims.Any(x => x.Type == "Allowed");

            if (!hasAllowedClaim)
            {
                ((ClaimsIdentity)principal.Identity).AddClaim(new Claim("Allowed", "Bad"));
            }

            return Task.FromResult(principal);
        }
    }
}
