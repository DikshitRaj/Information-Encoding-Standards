﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Authorization.Infrastructure;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Basics.Controllers
{
    public class OperationsController : Controller
    {
        private readonly IAuthorizationService _authorizationService;

        public OperationsController(IAuthorizationService authorizationService)
        {
            _authorizationService = authorizationService;
        }
        public async Task<IActionResult> Open()
        {
            var customName = new CustomName();
       
            await _authorizationService.AuthorizeAsync(User, customName, CustomAuthOperations.Open);
            
            return View();
        }

    }

    public class CustomAuthorizationHandler : AuthorizationHandler<OperationAuthorizationRequirement, CustomName>
    {
        protected override Task HandleRequirementAsync(AuthorizationHandlerContext context, 
            OperationAuthorizationRequirement requirement,
            CustomName customName)
        {
            if(requirement.Name == CustomOperations.ViewSomething)
            {
                if(context.User.Identity.IsAuthenticated)
                {
                    context.Succeed(requirement);
                }
            }
            else if(requirement.Name == CustomOperations.GetSomething)
            {
                if(context.User.HasClaim("Allowed","Good"))
                {
                    context.Succeed(requirement);
                }
            }
            return Task.CompletedTask;
        }
    }

    public static class CustomAuthOperations
    {
        public static OperationAuthorizationRequirement Open = new OperationAuthorizationRequirement
        {
            Name = CustomOperations.Open
        };
    }

    public static class CustomOperations
    {
        public static string Open = "Open";
        public static string Ping = "Ping";
        public static string GetSomething = "GetSomething";
        public static string ViewSomething = "ViewSomething";

    }

    public class CustomName
    {
        public string Name { get; set; }
    }
}
